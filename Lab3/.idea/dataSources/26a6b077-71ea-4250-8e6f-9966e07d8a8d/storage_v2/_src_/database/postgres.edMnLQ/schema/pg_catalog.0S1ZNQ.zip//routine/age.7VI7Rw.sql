create function age(timestamp with time zone) returns interval
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function age(timestamp with time zone) owner to postgres;

